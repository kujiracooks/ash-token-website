# The Ashley Archives — launch site

A static gossip-magazine-style launch site for $ASH.

## Files
- `index.html` — page structure and copy
- `styles.css` — the entire tabloid / gossip-magazine look
- `script.js` — countdown, CA reveal, Pump.fun link, archive cards, social links

## The only edits you NEED before launch
Open `script.js` and update:

```js
contractAddress: "PASTE_REAL_CA_HERE",
pumpFunUrl: "PASTE_FINAL_PUMPFUN_URL_HERE",
xUrl: "PASTE_X_URL_HERE",
telegramUrl: "PASTE_TELEGRAM_URL_HERE"
```

The countdown is already set for:
**August 19, 2026 at 1:00 PM Eastern (17:00 UTC).**

## Archive entries
The `ARCHIVES` array in `script.js` controls all numbered archive cards. Each item has:

- `number`
- `date`
- `label`
- `title`
- `summary`
- `source`
- `sourceLabel`

Keep serious claims sourced. Clearly distinguish allegations, charges, reporting, and established facts.

## Images
There are intentionally obvious placeholder boxes for:
- the cover image
- the official crayon Ashley mascot
- archive thumbnails

These can be replaced once the final image files are ready.

## Launch-day flow
- 8:00 AM EST: publish the website / domain
- 8:00 AM–1:00 PM EST: countdown runs, CA stays hidden
- 1:00 PM EST: countdown hits zero and the site automatically switches to the CA / Pump.fun state **if those values have been added to `script.js`**

Important: because a static site cannot magically know a CA you have not entered yet, add the CA and Pump.fun URL to `script.js` shortly before 1 PM and deploy that update.

## Hosting
This is plain HTML/CSS/JS, so it can be hosted on GitHub Pages, Cloudflare Pages, Netlify, Vercel, etc.
